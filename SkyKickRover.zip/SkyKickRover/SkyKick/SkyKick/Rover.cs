﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SkyKick
{
    /// <summary>
    /// Rover Class 
    /// </summary>
    public class Rover
    {
        private char direction;
        private int xPos;
        private int yPos;

        public char Direction
        {
            get => direction;
            set
            {
                if (validate_direction(value))
                {
                    direction = value;
                }
                else
                {
                    Console.WriteLine(value.ToString() + "is not a valid direction,Hence direction set to default 'N'");
                }

            }
        }
        public int XPos
        {
            get => xPos;

            set
            {
                if (value > -1)
                {
                    xPos = value;
                }
                else
                {
                    xPos = 0;
                }
            }
        }
        public int YPos
        {
            get => yPos;

            set
            {
                if (value > -1)
                {
                    yPos = value;
                }
                else
                {
                    yPos = 0;
                }
            }
        }

        /// <summary>
        /// To validate the direction of the Rover
        /// </summary>
        /// <param name="val">Input Direction to  be validated</param>
        /// <returns></returns>
        private bool validate_direction(char val)
        {
            List<Char> direction = new List<char>();
            direction.Add('N');
            direction.Add('S');
            direction.Add('E');
            direction.Add('W');
            bool flag = false;
            foreach (char i in direction)
            {
                if (i == val)
                {
                    flag = true;
                }
            }
            return flag;

        }

        /// <summary>
        /// Definition of how to move a rover.
        /// </summary>
        /// <param name="xGraph">Graph's right corner x vertices</param>
        /// <param name="yGraph">Graph's right corner y vertices</param>
        public void move_Rover(int xGraph,int yGraph)
        {
            char presentdirection = this.direction;
            if (presentdirection == 'N')
            {
                if ((this.yPos + 1) > -1 && (this.yPos + 1) <= yGraph)
                    this.yPos += 1;
                else
                    Console.WriteLine("This Position("+this.xPos+","+(this.yPos+1).ToString()+") is outside Graph,Skipped Command : M");
            }
            else if (presentdirection == 'S')
            {
                if ((this.yPos - 1) > -1 && (this.yPos - 1)<=yGraph)
                    this.yPos -= 1;
                else
                    Console.WriteLine("This Position(" + this.xPos + "," + (this.yPos-1).ToString() + ") is outside Graph,Skipped Command : M");
            }
            else if (presentdirection == 'E')
            {
                if ((this.xPos + 1) > -1 && (this.xPos + 1) <= xGraph)
                    this.XPos += 1;
                else
                    Console.WriteLine("This Position(" + (this.xPos+1).ToString() + "," + this.yPos + ") is outside Graph,Skipped Command : M");
            }
            else if (presentdirection == 'W')
            {

                if ((this.xPos - 1) > -1 && (this.xPos - 1) <= xGraph)
                    this.xPos -= 1;
                else
                    Console.WriteLine("This Position(" + (this.xPos-1 ).ToString()+ "," + this.yPos + ") is outside Graph,Skipped Command : M");
            }
        }

        /// <summary>
        /// This Method Turns the Rover
        /// </summary>
        /// <param name="direction">Direction to which the Rover needs to turn.</param>
        public void turn_Rover(char direction)
        {
            if(direction=='L')
            {
                switch(this.direction)
                {
                    case 'N': this.direction = 'W';
                        break;

                    case 'E':this.direction = 'N';
                        break;

                    case 'W': this.direction = 'S';
                        break;

                    case 'S':   this.direction = 'E';
                        break;

                    default:
                        break;
                }
            }
            else if (direction=='R')
            {
                switch (this.direction)
                {
                    case 'N':
                        this.direction = 'E';
                        break;

                    case 'E':
                        this.direction = 'S';
                        break;

                    case 'W':
                        this.direction = 'N';
                        break;

                    case 'S':
                        this.direction = 'W';
                        break;

                    default:
                        break;
                }
            }
        }
    }
}
