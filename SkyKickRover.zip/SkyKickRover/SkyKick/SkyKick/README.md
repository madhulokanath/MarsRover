﻿
# SkyKick Rover

## SPECIFICATION:

A squad of robotic rovers are to be landed by NASA on a plateau on Mars. The navigation team needs a
utility for them to simulate rover movements so they can develop a navigation plan.

A rover&#39;s position is represented by a combination of an x and y co-ordinates and a letter
representing one of the four cardinal compass points. The plateau is divided up into a grid to
simplify navigation. An example position might be 0, 0, N, which means the rover is in the bottom
left corner and facing North.

In order to control a rover, NASA sends a simple string of letters.The possible letters are:
'L'; – Make the rover spin 90 degrees left without moving from its current spot
'R'; - Make the rover spin 90 degrees right without moving from its current spot
'M';. Move forward one grid point, and maintain the same heading.
 
### Assumptions:
- Graph left down corner vertices is always: (0,0)
- The Rover can move with in the graph only.
- A Initial postion  should always be inside the graph
- If any command takes Rover outside graph, those commands are skipped
- Default initail position is '0 0 N'
- If intitail position is invalid, its set to deafult position.
- Default direction is North 'N'
- If the right  Coordinate of Rover is more than the graph Right cordinate, Its a wrong Initial position.

### How To Run:
 
- Enter once for the first time Upper Right Coordinates: as "xpos ypos"
- Now we enter a loop where we can reposition any number of Rovers until you press "Escape(Esc)"
- Provide Initial Position as "xpos ypos Direction"
- xpos value range : 0 <= xpos <=2147483647.>
- ypos value range : 0 <= ypos <=2147483647.>
- **Direction : ** 
 * 'N' for north 
 * 'S' for South 
 * 'W' for West
 * 'E' for East 
- Provide series of Commands as a string without spaces between 
- **Commands:**
 * 'L' for Left Turn 
 * 'R' for Right Turn 
 * 'M' for Move 
- You shall be given Final postion of Rover after the movemet. "xpos ypos Direction".

### Testing

Using MSTest Project (SkyKick_Test) we test our SkyKick project.
- In Project SkyKick_Test, go to project and add reference, Add SkyKick
- Now you can Test by Going to Test tab and select run all tests.

_Author: Madhu Lokanath_