﻿using System;
using System.Collections.Generic;

namespace SkyKick
{
    /// <summary>
    ///  A squad of robotic rovers are to be landed by NASA on a plateau on Mars. The navigation team needs a
    ///  utility for them to simulate rover movements so they can develop a navigation plan.
    ///  A rover&#39;s position is represented by a combination of an x and y co-ordinates and a letter
    ///  representing one of the four cardinal compass points. The plateau is divided up into a grid to
    ///  simplify navigation. An example position might be 0, 0, N, which means the rover is in the bottom
    ///  left corner and facing North.
    ///  In order to control a rover, NASA sends a simple string of letters.The possible letters are:
    ///  'L'; – Make the rover spin 90 degrees left without moving from its current spot
    ///  'R'; - Make the rover spin 90 degrees right without moving from its current spot
    ///  'M';. Move forward one grid point, and maintain the same heading.
    ///  
    /// Assumptions:
    /// 1. Graph left down corner Coordinate is always: (0,0)
    /// 2. The Rover can move with in the graph only.
    /// 3. A Initial postion  should always be inside the graph
    /// 4. If any command takes Rover outside graph, those commands are skipped
    /// 5. Default initail position is '0 0 N'
    /// 6. If intitail position is invalid, its set to deafult position.
    /// 7. Default direction is North 'N'
    /// 8. If the right  Coordinate of Rover is more than the graph Right cordinate, Its a wrong Initial position.
    /// 
    /// Author: Madhu Lokanath
    /// Phone: 3126468532
    /// Email: madhu.lokanath@gmail.com
    /// </summary>
    public class SkyKick_Rover
    {
        public const int MaxValue = 2147483647;

        /// <summary>
        /// Main Entry point of the Prrogram SkyKick_Rover
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            ConsoleKey key = ConsoleKey.Enter;
            int count = 0;
            Console.Write("Enter Graph Upper Right Coordinate: ");
            var gSize=getGraphsize(Console.ReadLine());
            while (key!=ConsoleKey.Escape)
            {
                count += 1;
                Console.Write("Rover "+count.ToString()+" Starting Position : ");
                string position= Console.ReadLine();
                Console.Write("Rover " + count.ToString() + " Movement Plan : ");
                string command = Console.ReadLine();
                var obj = new SkyKick_Rover();
                Console.WriteLine(obj.callExecute(position,command, count, gSize[0],gSize[1]));
                key =Console.ReadKey().Key;
            }
        }

        /// <summary>
        /// Inititalizes the graph's right corner with valid inputs,else use MavValue as the right corner of the graph. 
        /// </summary>
        /// <param name="graphSize"> Right Corner vertices of the graph</param>
        /// <returns></returns>
        public static List<int> getGraphsize(string graphSize)
        {
            List<Int32> gSize =new List<int>();
           
            string[] size = graphSize.Split(" ");
            try
            {
                if (size.Length == 2)
                {
                    gSize.Add(Convert.ToInt32(size[0]));
                    gSize.Add(Convert.ToInt32(size[1]));

                }
                else
                {
                    gSize.Add(MaxValue);
                    gSize.Add(MaxValue);
                }
            }
            catch (Exception e)
            {
                gSize.Add(MaxValue);
                gSize.Add(MaxValue);
                Console.WriteLine("Error while getting Graph size:Hence graph set to max value"+e.Message);
                //throw;
            }
            return gSize;
        }

        /// <summary>
        /// This method assigns new position and direction to the Rover by executing provided commands.
        /// </summary>
        /// <param name="cmd">List of commands Chars (LRM) string</param>
        /// <param name="a"> Rover is initialized and assigned value.</param>
        /// <param name="XGraph">Right corner 'x' Coordinate of the graph</param>
        /// <param name="YGraph">Right corner 'y' Coordinate of the graph</param>
        public static void executeCommand(string cmd,Rover a,int XGraph,int YGraph)
        {


            if(cmd.Length>0)
            {
                foreach(char i in cmd.ToUpper())
                {
                    if (i == 'L' || i == 'R' || i == 'M')
                    {

                        if (i == 'M')
                        {
                            
                            a.move_Rover(XGraph, YGraph);
                        }
                        else
                        {
                            a.turn_Rover(i);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid command:"+i+",command skipped,Command string should consists on 'LMR' (L-->left,R-->right,M-->Move)");
                        //return;
                    }
                }
               
            }
            
        }

        /// <summary>
        /// This Method is excluded from main, so it can be consumed for Testing purposes.
        /// </summary>
        /// <param name="position">Input string which holds initial posistion of the Rover, if Invalid its set ti default position '0 0 N'</param>
        /// <param name="cmd">Input string holding series of Commands to be executed by Rover (L-> Left Turn,R-> Right Turn ,M -> Move)</param>
        /// <param name="count">This Keeps Count of Rovers</param>
        /// <param name="XGraph">Right corner 'x' Coordinate of the graph</param>
        /// <param name="YGraph">Right corner 'y' Coordinate of the graph</param>
        /// <returns></returns>
        public string callExecute(string position,string cmd,int count,int XGraph,int YGraph)
        {
            string res = "";
            Rover ab = new Rover();
            //setting default direction to North (N)
            ab.Direction = 'N';
            string[] input = position.Split(" ");
            if (input.Length == 3)
            {
                try
                {
                    ab.XPos = Convert.ToInt32(input[0]);
                    ab.YPos = Convert.ToInt32(input[1]);
                    ab.Direction = Convert.ToChar(input[2]);
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid Position input, Default Position set to : 0 0 N");
                    ab.XPos = 0;
                    ab.YPos = 0;                   
                }
            }
            else
            {
                Console.WriteLine("Invalid Position: Default Position set to : 0 0 N");
            }
            if (ab.XPos <= XGraph &&  ab.YPos  <= YGraph)
            {
                executeCommand(cmd, ab, XGraph, YGraph);
                
            }
            else
            {
                res="Wrong Initital position of Rover "+count;
                return res;
            }
            res = "Rover " + count.ToString() + " Output: " + ab.XPos + " " + ab.YPos + " " + ab.Direction;
            return res;
        }
    }
}

