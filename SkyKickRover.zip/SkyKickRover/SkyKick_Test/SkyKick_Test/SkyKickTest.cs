using Microsoft.VisualStudio.TestTools.UnitTesting;
using SkyKick;

namespace SkyKick.Test
{
    [TestClass]
    public class SkyKickTest
    {
              
        private readonly SkyKick_Rover skyKick;

        public SkyKickTest()
        {
            skyKick = new SkyKick_Rover();
        }

        /// <summary>
        /// First Sample Test provided
        /// </summary>
        [TestMethod]
        public  void SampleTest1()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("1 2 N", "LMLMLMLMM", 1,xGraph,yGraph);
           Assert.AreEqual(res, "Rover 1 Output: 1 3 N");          
        }

        /// <summary>
        /// Second sample Test provided
        /// </summary>
        [TestMethod]
        public void SampleTest2()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("3 3 E", "MMRMMRMRRM", 1,xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 5 1 E");
        }

        /// <summary>
        /// Test Empty Initial position
        /// </summary>
        [TestMethod]
        public void Test_EmptyInitialPosition()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("", "RLR", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 0 E");
        }

        /// <summary>
        /// Test method for wrong Initial position
        /// </summary>
        [TestMethod]
        public void Test_WrongInitialPosition()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("6 7 N", "LM", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Wrong Initital position of Rover 1");
        }

        /// <summary>
        /// Test Invalid Initial position
        /// </summary>
        [TestMethod]
        public void Test_InvalidInitialPosition()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("Invalid", "RLR", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 0 E");
        }


        /// <summary>
        /// Test Invalid command1, (All invalid commands)
        /// </summary>
        [TestMethod]
        public void Test_InvalidCommand1()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("0 0 N", "xxxxx", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 0 N");
        }


        /// <summary>
        /// Test Invalid command2,( Mix of valid and invalid commands)
        /// </summary>
        [TestMethod]
        public void Test_InvalidCommand2()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("0 0 N", "MOSTUVLWR", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 1 N");
        }

        /// <summary>
        /// Test empty command2
        /// </summary>
        [TestMethod]
        public void Test_EmptyCommand()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("0 0 N", "", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 0 N");
        }

        /// <summary>
        /// Test command, which takes rover outside graph
        /// </summary>
        [TestMethod]
        public void Test_RoverMoveOut()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("0 0 N", "LMMM", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 0 W");
        }

        /// <summary>
        /// Test command, which takes rover outside graph and brings back in.
        /// </summary>
        [TestMethod]
        public void Test_RoverMoveOutIN()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("0 0 N", "LMMMRMMLM", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 2 W");
        }

        /// <summary>
        /// Random Test input
        /// </summary>
        [TestMethod]
        public void Test_Randomsample1()
        {
            int xGraph = 100;
            int yGraph = 100;
            string res = skyKick.callExecute("1 2 N", "LM", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 2 W");
        }

        /// <summary>
        /// Random Test input
        /// </summary>
        [TestMethod]
        public void Test_Randomsample2()
        {
            int xGraph = 100;
            int yGraph = 100;
            string res = skyKick.callExecute("1 2 N", "LMLMLMMMRR", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 3 1 W");
        }

        /// <summary>
        /// Random Test input
        /// </summary>
        [TestMethod]
        public void Test_Randomsample3()
        {
            int xGraph = 5;
            int yGraph = 5;
            string res = skyKick.callExecute("3 3 N", "LMLMMMMMLLLLMMMLMLMMMMMRMRMMMMMRMMMMMRMM", 1, xGraph, yGraph);
            Assert.AreEqual(res, "Rover 1 Output: 0 2 N");
        }

        
    }
}
